/**
 * 数据管理系统 - JavaScript逻辑文件 v2.0
 * 功能模块：登录认证、文件上传、数据查询展示、主题切换、统计卡片
 */

// 本地存储键名常量
const STORAGE_KEYS = {
    USERS: 'data_sys_users',
    SESSION: 'data_sys_session',
    DATA: 'data_sys_files',
    SETTINGS: 'data_sys_settings',
    THEME: 'data_sys_theme'
};

// DOM元素 - 登录模块
const loginContainer = document.getElementById('login-container');
const mainContainer = document.getElementById('main-container');
const loginForm = document.getElementById('login-form');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const rememberPwdCheckbox = document.getElementById('remember-pwd');
const autoLoginCheckbox = document.getElementById('auto-login');
const userInfoSpan = document.getElementById('user-info');
const logoutBtn = document.getElementById('logout-btn');

// DOM元素 - 主题切换
const themeToggle = document.getElementById('theme-toggle');

// DOM元素 - 上传模块
const uploadArea = document.getElementById('upload-area');
const fileInput = document.getElementById('file-input');
const uploadProgress = document.getElementById('upload-progress');
const progressBar = document.getElementById('progress-bar');
const progressText = document.getElementById('progress-text');

// DOM元素 - 搜索筛选
const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');
const categoryFilter = document.getElementById('category-filter');

// DOM元素 - 表格展示
const tableBody = document.getElementById('table-body');
const emptyState = document.getElementById('empty-state');
const emptyTitle = document.getElementById('empty-title');
const emptyDesc = document.getElementById('empty-desc');
const resultCount = document.getElementById('result-count');

// DOM元素 - 统计卡片
const statTotal = document.getElementById('stat-total');
const statH = document.getElementById('stat-H');
const statG = document.getElementById('stat-G');
const statM = document.getElementById('stat-M');
const statL = document.getElementById('stat-L');

// DOM元素 - Toast和Loading
const toastContainer = document.getElementById('toast-container');
const loadingOverlay = document.getElementById('loading-overlay');

// 当前登录用户
let currentUser = null;

// 文件数据列表
let fileDataList = [];

// 当前筛选状态
let currentFilter = {
    keyword: '',
    category: ''
};

/**
 * 初始化函数 - 页面加载时执行
 */
function init() {
    loadUsers();
    loadFileData();
    loadSettings();
    initTheme();

    if (checkAutoLogin()) {
        return;
    }

    showLogin();
}

/**
 * 加载用户数据（从localStorage）
 */
function loadUsers() {
    const usersStr = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!usersStr) {
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify([]));
    }
}

/**
 * 加载文件数据（从localStorage）
 */
function loadFileData() {
    const dataStr = localStorage.getItem(STORAGE_KEYS.DATA);
    fileDataList = dataStr ? JSON.parse(dataStr) : [];
}

/**
 * 加载设置（从localStorage）
 */
function loadSettings() {
    const settingsStr = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!settingsStr) {
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify({
            rememberPwd: false,
            autoLogin: false,
            lastUsername: '',
            lastPassword: ''
        }));
    }
}

/**
 * 初始化主题设置
 */
function initTheme() {
    const savedTheme = localStorage.getItem(STORAGE_KEYS.THEME);
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
        updateThemeIcon(savedTheme);
    }
}

/**
 * 更新主题图标
 */
function updateThemeIcon(theme) {
    themeToggle.textContent = theme === 'dark' ? '☀️' : '🌙';
}

/**
 * 切换主题
 */
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem(STORAGE_KEYS.THEME, newTheme);
    updateThemeIcon(newTheme);
}

/**
 * 检查是否需要自动登录
 */
function checkAutoLogin() {
    const settings = getSettings();

    if (settings.autoLogin && settings.lastUsername && settings.lastPassword) {
        const loginResult = login(settings.lastUsername, settings.lastPassword);
        if (loginResult.success) {
            showMain();
            return true;
        }
    }

    if (settings.rememberPwd && settings.lastUsername && settings.lastPassword) {
        usernameInput.value = settings.lastUsername;
        passwordInput.value = settings.lastPassword;
        rememberPwdCheckbox.checked = true;
    }

    return false;
}

/**
 * 获取设置
 */
function getSettings() {
    const settingsStr = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return settingsStr ? JSON.parse(settingsStr) : {
        rememberPwd: false,
        autoLogin: false,
        lastUsername: '',
        lastPassword: ''
    };
}

/**
 * 保存设置
 */
function saveSettings(settings) {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
}

/**
 * 登录验证
 */
function login(username, password) {
    const users = getUsers();
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        currentUser = user;
        saveSession(user);
        return { success: true, message: '登录成功' };
    } else {
        const newUser = {
            id: Date.now(),
            username: username,
            password: password,
            createdAt: new Date().toISOString()
        };

        users.push(newUser);
        saveUsers(users);

        currentUser = newUser;
        saveSession(newUser);
        return { success: true, message: '新用户已创建并登录' };
    }
}

/**
 * 获取用户列表
 */
function getUsers() {
    const usersStr = localStorage.getItem(STORAGE_KEYS.USERS);
    return usersStr ? JSON.parse(usersStr) : [];
}

/**
 * 保存用户列表
 */
function saveUsers(users) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}

/**
 * 保存登录会话
 */
function saveSession(user) {
    localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify({
        userId: user.id,
        username: user.username,
        loginTime: new Date().toISOString()
    }));
}

/**
 * 清除登录会话
 */
function clearSession() {
    localStorage.removeItem(STORAGE_KEYS.SESSION);
    currentUser = null;
}

/**
 * 显示登录界面
 */
function showLogin() {
    loginContainer.classList.remove('hidden');
    mainContainer.classList.add('hidden');
}

/**
 * 显示主界面
 */
function showMain() {
    loginContainer.classList.add('hidden');
    mainContainer.classList.remove('hidden');

    userInfoSpan.textContent = `👤 ${currentUser.username}`;

    updateStats();
    renderTable(fileDataList);
}

/**
 * 更新统计卡片数据
 */
function updateStats() {
    const counts = {
        total: fileDataList.length,
        H: 0,
        G: 0,
        M: 0,
        L: 0
    };

    fileDataList.forEach(item => {
        if (counts[item.category] !== undefined) {
            counts[item.category]++;
        }
    });

    animateNumber(statTotal, counts.total);
    animateNumber(statH, counts.H);
    animateNumber(statG, counts.G);
    animateNumber(statM, counts.M);
    animateNumber(statL, counts.L);
}

/**
 * 数字动画效果
 */
function animateNumber(element, targetNumber) {
    const currentNumber = parseInt(element.textContent) || 0;
    const duration = 500;
    const startTime = performance.now();

    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);

        const easeProgress = 1 - Math.pow(1 - progress, 3);
        const displayNumber = Math.floor(currentNumber + (targetNumber - currentNumber) * easeProgress);

        element.textContent = displayNumber;

        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }

    requestAnimationFrame(update);
}

/**
 * 渲染数据表格
 */
function renderTable(data) {
    tableBody.innerHTML = '';

    if (data.length === 0) {
        emptyState.classList.remove('hidden');
        resultCount.textContent = '';
        updateEmptyState();
    } else {
        emptyState.classList.add('hidden');
        resultCount.textContent = `(共 ${data.length} 条)`;

        data.forEach((item, index) => {
            const row = document.createElement('tr');
            row.style.animationDelay = `${index * 0.05}s`;

            const nameCell = document.createElement('td');
            nameCell.innerHTML = `<div class="file-name"><span class="file-icon">📄</span>${item.name}</div>`;
            row.appendChild(nameCell);

            const categoryCell = document.createElement('td');
            const categoryTag = document.createElement('span');
            categoryTag.className = `category-tag category-${item.category}`;
            categoryTag.textContent = `${item.category}类`;
            categoryCell.appendChild(categoryTag);
            row.appendChild(categoryCell);

            const sizeCell = document.createElement('td');
            sizeCell.textContent = formatFileSize(item.size);
            row.appendChild(sizeCell);

            const timeCell = document.createElement('td');
            timeCell.textContent = formatDateTime(item.uploadTime);
            row.appendChild(timeCell);

            const actionCell = document.createElement('td');
            actionCell.innerHTML = `
                <button class="action-btn action-btn-download" onclick="downloadFile(${item.id})" title="下载">⬇️ 下载</button>
                <button class="action-btn action-btn-delete" onclick="deleteFile(${item.id})" title="删除">🗑️ 删除</button>
            `;
            row.appendChild(actionCell);

            tableBody.appendChild(row);
        });
    }
}

/**
 * 更新空状态提示
 */
function updateEmptyState() {
    const hasKeyword = currentFilter.keyword.trim() !== '';
    const hasCategory = currentFilter.category !== '';

    if (hasKeyword || hasCategory) {
        emptyTitle.textContent = '未找到匹配结果';
        emptyDesc.textContent = '请尝试调整搜索条件';
        emptyState.querySelector('.empty-state-icon').textContent = '🔍';
    } else {
        emptyTitle.textContent = '暂无数据';
        emptyDesc.textContent = '请上传文件以开始使用';
        emptyState.querySelector('.empty-state-icon').textContent = '📂';
    }
}

/**
 * 格式化文件大小
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';

    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * 格式化日期时间
 */
function formatDateTime(dateStr) {
    const date = new Date(dateStr);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}`;
}

/**
 * 根据文件名自动识别类别
 */
function detectCategory(fileName) {
    const lowerName = fileName.toLowerCase();

    const rules = [
        { category: 'H', keywords: ['high', '重要', '核心', '关键', '首要', '顶级', '高级'] },
        { category: 'G', keywords: ['general', '普通', '通用', '常规', '标准', '基础'] },
        { category: 'M', keywords: ['medium', '中等', '一般', '中级', '中间', '普通'] },
        { category: 'L', keywords: ['low', '低', '次要', '低级', '基础', '简单'] }
    ];

    for (const rule of rules) {
        if (rule.keywords.some(keyword => lowerName.includes(keyword))) {
            return rule.category;
        }
    }

    const firstChar = fileName.charAt(0).toUpperCase();
    const charCode = firstChar.charCodeAt(0);

    if (charCode >= 65 && charCode <= 78) {
        return 'H';
    } else if (charCode >= 79 && charCode <= 83) {
        return 'G';
    } else if (charCode >= 84 && charCode <= 87) {
        return 'M';
    } else {
        return 'L';
    }
}

/**
 * 保存文件数据到本地存储
 */
function saveFileData() {
    localStorage.setItem(STORAGE_KEYS.DATA, JSON.stringify(fileDataList));
}

/**
 * 处理文件上传（带进度条和内容读取）
 */
function handleFiles(files) {
    if (files.length === 0) return;

    let successCount = 0;
    let totalFiles = files.length;
    let processedCount = 0;

    uploadProgress.classList.add('active');
    uploadArea.classList.add('uploading');

    const processFile = (file, index) => {
        const reader = new FileReader();

        reader.onload = (e) => {
            const content = e.target.result;
            
            const fileData = {
                id: Date.now() + index,
                name: file.name,
                size: file.size,
                category: detectCategory(file.name),
                uploadTime: new Date().toISOString(),
                content: content.slice(0, 5000)
            };

            fileDataList.unshift(fileData);
            successCount++;
            processedCount++;

            const progress = (processedCount / totalFiles) * 100;
            progressBar.style.width = progress + '%';
            progressText.textContent = `上传中... ${Math.floor(progress)}%`;

            if (processedCount >= totalFiles) {
                completeUpload();
            }
        };

        reader.onerror = () => {
            const fileData = {
                id: Date.now() + index,
                name: file.name,
                size: file.size,
                category: detectCategory(file.name),
                uploadTime: new Date().toISOString(),
                content: ''
            };

            fileDataList.unshift(fileData);
            successCount++;
            processedCount++;

            const progress = (processedCount / totalFiles) * 100;
            progressBar.style.width = progress + '%';
            progressText.textContent = `上传中... ${Math.floor(progress)}%`;

            if (processedCount >= totalFiles) {
                completeUpload();
            }
        };

        reader.readAsText(file, 'UTF-8');
    };

    const completeUpload = () => {
        setTimeout(() => {
            saveFileData();
            updateStats();
            searchAndFilter();

            uploadProgress.classList.remove('active');
            uploadArea.classList.remove('uploading');
            progressBar.style.width = '0%';

            showToast('success', '上传成功', `成功上传 ${successCount} 个文件`);
            showFloatPlus(successCount);
            fileInput.value = '';
        }, 300);
    };

    progressBar.style.width = '0%';
    progressText.textContent = '上传中... 0%';

    for (let i = 0; i < files.length; i++) {
        processFile(files[i], i);
    }
}

/**
 * 显示+1飘出动画
 */
function showFloatPlus(count) {
    const floatEl = document.createElement('div');
    floatEl.className = 'float-plus';
    floatEl.textContent = `+${count}`;

    const rect = uploadArea.getBoundingClientRect();
    floatEl.style.left = rect.left + rect.width / 2 - 20 + 'px';
    floatEl.style.top = rect.top + 'px';

    document.body.appendChild(floatEl);

    setTimeout(() => {
        floatEl.remove();
    }, 800);
}

/**
 * 下载文件（模拟）
 */
function downloadFile(id) {
    const file = fileDataList.find(f => f.id === id);
    if (file) {
        showToast('info', '下载功能', `正在下载: ${file.name}`);
    }
}

/**
 * 删除文件
 */
function deleteFile(id) {
    const file = fileDataList.find(f => f.id === id);
    if (!file) return;

    if (confirm(`确定要删除文件 "${file.name}" 吗？`)) {
        fileDataList = fileDataList.filter(f => f.id !== id);
        saveFileData();
        updateStats();
        searchAndFilter();
        showToast('success', '删除成功', `已删除文件: ${file.name}`);
    }
}

/**
 * 搜索和筛选数据（支持搜索文件名和内容）
 */
function searchAndFilter() {
    currentFilter.keyword = searchInput.value.toLowerCase().trim();
    currentFilter.category = categoryFilter.value;

    let filtered = fileDataList;

    if (currentFilter.category) {
        filtered = filtered.filter(item => item.category === currentFilter.category);
    }

    if (currentFilter.keyword) {
        filtered = filtered.filter(item => {
            const matchName = item.name.toLowerCase().includes(currentFilter.keyword);
            const matchContent = item.content && item.content.toLowerCase().includes(currentFilter.keyword);
            return matchName || matchContent;
        });
    }

    renderTable(filtered);
}

/**
 * 显示Toast弹窗
 */
function showToast(type, title, message) {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const iconMap = {
        success: '✅',
        error: '❌',
        info: 'ℹ️'
    };

    toast.innerHTML = `
        <div class="toast-icon">${iconMap[type]}</div>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
    `;

    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('hiding');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

/**
 * 显示Loading
 */
function showLoading() {
    loadingOverlay.classList.remove('hidden');
}

/**
 * 隐藏Loading
 */
function hideLoading() {
    loadingOverlay.classList.add('hidden');
}

/**
 * 登录表单提交处理
 */
loginForm.addEventListener('submit', function(e) {
    e.preventDefault();

    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    if (!username || !password) {
        showToast('error', '登录失败', '请输入账号和密码');
        return;
    }

    showLoading();

    setTimeout(() => {
        const result = login(username, password);

        const settings = {
            rememberPwd: rememberPwdCheckbox.checked,
            autoLogin: autoLoginCheckbox.checked,
            lastUsername: rememberPwdCheckbox.checked ? username : '',
            lastPassword: rememberPwdCheckbox.checked ? password : ''
        };
        saveSettings(settings);

        hideLoading();

        showToast(result.success ? 'success' : 'error',
            result.success ? '登录成功' : '登录失败',
            result.message);

        if (result.success) {
            showMain();
        }
    }, 500);
});

/**
 * 退出登录处理
 */
logoutBtn.addEventListener('click', function() {
    clearSession();

    const settings = getSettings();
    if (!settings.rememberPwd) {
        usernameInput.value = '';
        passwordInput.value = '';
    }

    showLogin();
    showToast('info', '已退出', '期待下次再见！');
});

/**
 * 主题切换处理
 */
themeToggle.addEventListener('click', toggleTheme);

/**
 * 上传区域点击处理
 */
uploadArea.addEventListener('click', function() {
    fileInput.click();
});

/**
 * 文件选择处理
 */
fileInput.addEventListener('change', function(e) {
    if (e.target.files.length > 0) {
        handleFiles(e.target.files);
    }
});

/**
 * 拖拽事件处理 - 拖拽进入
 */
uploadArea.addEventListener('dragover', function(e) {
    e.preventDefault();
    uploadArea.classList.add('dragover');
});

/**
 * 拖拽事件处理 - 拖拽离开
 */
uploadArea.addEventListener('dragleave', function(e) {
    e.preventDefault();
    uploadArea.classList.remove('dragover');
});

/**
 * 拖拽事件处理 - 放置文件
 */
uploadArea.addEventListener('drop', function(e) {
    e.preventDefault();
    uploadArea.classList.remove('dragover');

    if (e.dataTransfer.files.length > 0) {
        handleFiles(e.dataTransfer.files);
    }
});

/**
 * 搜索按钮点击处理
 */
searchBtn.addEventListener('click', searchAndFilter);

/**
 * 搜索输入框回车处理
 */
searchInput.addEventListener('keyup', function(e) {
    if (e.key === 'Enter') {
        searchAndFilter();
    }
});

/**
 * 实时搜索（输入时）
 */
searchInput.addEventListener('input', function() {
    searchAndFilter();
});

/**
 * 分类筛选变化处理
 */
categoryFilter.addEventListener('change', searchAndFilter);

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', init);